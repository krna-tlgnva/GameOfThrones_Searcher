import 'package:flutter/material.dart';

class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});

  final Widget child;

  static const Color white = Color(0xFFFFFFFF);
  static const Color paleLilac = Color(0xFFF7F1FF);
  static const Color softViolet = Color(0xFFE2D2FF);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [white, paleLilac, softViolet],
          stops: [0.0, 0.48, 1.0],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: child,
    );
  }
}
