import 'package:flutter/material.dart';

import 'app_background.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({
    super.key,
    required this.title,
    required this.body,
    this.actions,
    this.floatingActionButton,
    this.currentIndex,
    this.onDestinationSelected,
  });

  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? floatingActionButton;
  final int? currentIndex;
  final ValueChanged<int>? onDestinationSelected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.auto_awesome, size: 20),
            const SizedBox(width: 8),
            Flexible(child: Text(title, overflow: TextOverflow.ellipsis)),
          ],
        ),
        actions: actions,
      ),
      body: AppBackground(child: body),
      floatingActionButton: floatingActionButton,
      bottomNavigationBar: currentIndex == null || onDestinationSelected == null
          ? null
          : NavigationBar(
              selectedIndex: currentIndex!,
              onDestinationSelected: onDestinationSelected!,
              labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.auto_awesome),
                  label: 'Characters',
                ),
                NavigationDestination(
                  icon: Icon(Icons.bookmark_added_outlined),
                  label: 'My Characters',
                ),
                NavigationDestination(
                  icon: Icon(Icons.archive_outlined),
                  label: 'Archive',
                ),
              ],
            ),
    );
  }
}
