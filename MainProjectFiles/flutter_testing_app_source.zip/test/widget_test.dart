import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_testing_app/repositories/character_repository.dart';
import 'package:flutter_testing_app/screens/create_character_screen.dart';
import 'package:flutter_testing_app/screens/intro_screen.dart';
import 'package:flutter_testing_app/services/api_service.dart';
import 'package:flutter_testing_app/services/local_service.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  setUpAll(() {
    GoogleFonts.config.allowRuntimeFetching = false;
  });

  testWidgets('intro start button opens the app area', (tester) async {
    await tester.pumpWidget(const _IntroTestHost());

    expect(find.text('LOAD THE APP'), findsOneWidget);
    expect(find.text('Opened Realm'), findsNothing);

    await tester.tap(find.text('LOAD THE APP'));
    await tester.pump();

    expect(find.text('Opened Realm'), findsOneWidget);
  });

  testWidgets('create character form shows validation after Save tap', (
    tester,
  ) async {
    final repository = CharacterRepository(
      apiService: ApiService(),
      localCharacterService: LocalCharacterService(),
    );

    await tester.pumpWidget(
      MaterialApp(home: CreateCharacterScreen(repository: repository)),
    );

    await tester.tap(find.text('Save'));
    await tester.pump();

    expect(find.text('Please enter a name.'), findsOneWidget);
    expect(find.text('Please enter a title or skill.'), findsOneWidget);
  });
}

class _IntroTestHost extends StatefulWidget {
  const _IntroTestHost();

  @override
  State<_IntroTestHost> createState() => _IntroTestHostState();
}

class _IntroTestHostState extends State<_IntroTestHost> {
  bool opened = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: opened
          ? const Scaffold(body: Center(child: Text('Opened Realm')))
          : IntroScreen(
              onStart: () {
                setState(() {
                  opened = true;
                });
              },
            ),
    );
  }
}
